# sehi
A Restaurant Website Template Design

**The Used Languages and libraries:**
- Html 5
- Css 3
- JavaScript
- Jquery
- Font Awesome
- WOW.js
- Google Fonts

**To See The Website Preview Go to** [Sehi](https://sehi.netlify.com)
