# techado
Ecommerce Template

**The Used Languages and libraries:**
- Html 5
- Css 3
- Jquery
- Font Awesome
- Google Fonts

**To See The Website Preview Go to** [Techado](https://ecommercetechado.netlify.com/)
